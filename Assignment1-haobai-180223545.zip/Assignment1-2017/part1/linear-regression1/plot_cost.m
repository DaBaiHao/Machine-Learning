function plot_cost(J)
    figure(2);

    plot(J);
    
    xlabel('itarations');
    ylabel('cost');
end