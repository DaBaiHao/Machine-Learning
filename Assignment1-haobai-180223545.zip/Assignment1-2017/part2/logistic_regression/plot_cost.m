function h=plot_cost(J)
    h=figure('Name','cost');
    plot(J)
    xlabel('iterations')
    ylabel('cost')
    
    %END OF FUNCTION

    