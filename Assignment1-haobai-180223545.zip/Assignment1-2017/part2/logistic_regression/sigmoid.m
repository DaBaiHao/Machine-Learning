function output=sigmoid(z)
    %output = 0;
    % modify this to return z passed through the sigmoid function
    %%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%
    
    output = 1./(1+exp(-z));
    
    
    
    
%END OF FUNCTION
end

