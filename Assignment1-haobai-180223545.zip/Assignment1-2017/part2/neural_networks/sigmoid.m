
        
        
        
        
        function  sigmoid_output=sigmoid(z)
            % change this to apply the sigmoid to the data below:
            
            sigmoid_output = 1 ./ (1 + exp(-z));
            
        end