
        
        function derivative=sigmoid_derivative(a)
            %
            %assumes sigmoided input
            %
            derivative=a*(1.0-a);
        end