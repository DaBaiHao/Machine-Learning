# README

### How to get the task 1 result

run the file *task1.m*

### How to get the task 2 result
run the file mog and change the x = x1 or x = x2, is the phno1 or phno2, and change K.

### How to get the task 3 result
1. After run the file **mog.m** and change the x = x1 or x = x2, is the phno1 or phno2, and change K.
2. run the file **task3andTask4.m** first line.

### How to get the task 4 result
1. After run the file **mog.m** and change the x = x1 or x = x2, is the phno1 or phno2, and change K.
2. run the file **task3andTask4.m** second line.

### How to get the task 5 result
1. After run the file **mog.m** and change the x = x1 or x = x2, is the phno1 or phno2, and change **K = 3**.
2. run the file **task5.m** second line.
